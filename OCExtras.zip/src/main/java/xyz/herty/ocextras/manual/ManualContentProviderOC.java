package xyz.herty.ocextras.manual;

import li.cil.oc.api.manual.ContentProvider;
import li.cil.oc.api.manual.PathProvider;

public class ManualContentProviderOC extends ManualContentProvider implements ContentProvider {
}
